'use client';

import { BillingPage } from '@flowglad/nextjs';

export default function Billing() {
  return <BillingPage />;
}
